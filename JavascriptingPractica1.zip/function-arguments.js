function math(num1, num2, num3){
	num1 += num2 * num3;
	return num1;
}

console.log(math(53,61,67));